//Type your code here
function panges() {
    var setupTblSwipe = {
        fingers: 1,
        continuousEvents: true
    };
    frmHome.addGestureRecognizer(constants.GESTURE_TYPE_PAN, setupTblSwipe, formGesture);
    valueofbegin = 0;
}

function mySwipe() {
    alert("hi");
}
var valueofbegin;
var valueonmove;

function formGesture(widgetID, gestureInfo) {
    var y = kony.type(gestureInfo); //expected value of y = table
    var z = kony.type(gestureInfo.gesturesetUpParams); //expected values of z = table
    var a = gestureInfo.gestureType;
    var b = gestureInfo.gesturesetUpParams;
    var c = gestureInfo.gesturePosition;
    var d = gestureInfo.gestureX;
    var e = gestureInfo.gestureY;
    var f = gestureInfo.widgetWidth;
    var g = gestureInfo.widgetHeight;
    var gestureState = gestureInfo.gestureState;
    if (gestureInfo.gestureState == "1") {
        valueofbegin = d;
    } else if (gestureInfo.gestureState == "2") {
        valueonmove = d - valueofbegin;
        if (valueonmove > 0) {
            //do nothing
        } else {
            frmHome.FlexContainerPan.left = valueonmove;
        }
    } else if (gestureInfo.gestureState == "3") {
        valueonmove = d - valueofbegin;
        if (valueonmove < -150) {
            //frmHome.FlexContainerPAn.left = -300;
            menuclose();
        } else if (valueonmove > -150) {
            //frmHome.FlexContainerPAn.left = 0;
            menuopen();
        }
    }
    kony.print("gestureX is: " + d);
    kony.print("valueofbegin is: " + valueofbegin);
    kony.print("valueonmove is: " + valueonmove);
    kony.print("gestureInfo.gestureState is: " + gestureInfo.gestureState); //gestureType=1 or 2 or 3
    kony.print("*******************************************");
    if (kony.os.toNumber(gestureInfo.gestureType) == 2) {} else {
        h = ""
    }
    if (kony.os.toNumber(a) == 1) {
        b1 = "fingers: " + gestureInfo.gesturesetUpParams.fingers;
        b2 = "taps: " + gestureInfo.gesturesetUpParams.taps;
        //kony.print(""+b1+""+b2);
    } else if (kony.os.toNumber(a) == 2) {
        b1 = "fingers :" + gestureInfo.gesturesetUpParams.fingers;
        b2 = "";
        //kony.print(""+b1+""+b2);
    } else if (kony.os.toNumber(a) == 3) {
        b1 = "pressduration:" + gestureInfo.gesturesetUpParams
            //pressDuration;
        b2 = "";
        //kony.print(""+b1+""+b2);
    }
    h = gestureInfo.swipeDirection;
    //  kony.print("swipe direction is: "+h);
    // 	kony.print("widget id is: "+widgetID); //will print the widgetID. To print widgetID use widgetID.id 
    // 	kony.print("type of gestureInfo is: "+y);
    //   //
    //   //alert(d+","+e);
    // 	kony.print("type of gesturesetUpParams is: "+z);
    // 	kony.print("gestureType is: "+a); //gestureType=1 or 2 or 3
    // 	kony.print("gesturesetUpParams is: "+b.fingers); //gesturesetUpParams 
    // //= {fingers =1, taps =1} or {fingers =1, taps =2} or {fingers =1} or {pressDuration = 1}
    // 	kony.print("gesturePosition is: "+c); //gesturePosition=1 or 2 or 3 or .....9
    // 	 //ex: gestureX=30
    // 	kony.print("gestureY is: "+e); //ex: gestureY=100
    // 	kony.print("widgetWidth is: "+f); //ex: widgetWidth=320
    // 	kony.print("widgetHeight is: "+g); //ex: widgetHeight=28
    //gesturePosition, gestureX, gestureY, widgetWidth, widgetHeight params are not applicable in android
    //kony.print("*******************************************");
}

function menuopen() {
    kony.print("menuopen");

    function MOVE_ACTION____e80278dbb4a0446c970bc90dca78687d_Callback() {}
    frmHome.FlexContainerPan.animate(kony.ui.createAnimation({
        "100": {
            "top": "0px",
            "left": "0px",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25,
        "direction": kony.anim.DIRECTION_NONE
    }, {
        "animationEnd": MOVE_ACTION____e80278dbb4a0446c970bc90dca78687d_Callback
    });
}

function menuclose() {
    kony.print("menuclose");

    function MOVE_ACTION____e80278dbb4a0446c970bc90dca78687d_Callback() {}
    frmHome.FlexContainerPan.animate(kony.ui.createAnimation({
        "100": {
            "top": "0px",
            "left": "-300dp",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25,
        "direction": kony.anim.DIRECTION_NONE
    }, {
        "animationEnd": MOVE_ACTION____e80278dbb4a0446c970bc90dca78687d_Callback
    });
}