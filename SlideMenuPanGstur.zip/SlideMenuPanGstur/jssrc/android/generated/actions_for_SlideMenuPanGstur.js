//actions.js file 
function AS_Button_ge0ad1cc07174573a60d7c2ed6c60636(eventobject) {
    function MOVE_ACTION____e80278dbb4a0446c970bc90dca78687d_Callback() {}
    frmHome.FlexContainerPan.animate(kony.ui.createAnimation({
        "100": {
            "top": "0px",
            "left": "0dp",
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25,
        "direction": kony.anim.DIRECTION_NONE
    }, {
        "animationEnd": MOVE_ACTION____e80278dbb4a0446c970bc90dca78687d_Callback
    });
}

function AS_Form_c4303ed698814871af8a170a73397cf7(eventobject) {
    return panges.call(this);
}