function initializeFBox0cd48d585cadd45() {
    FBox0cd48d585cadd45 = new kony.ui.FlexContainer({
        "clipBounds": false,
        "height": "40dp",
        "id": "FBox0cd48d585cadd45",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "width": "100%"
    }, {
        "containerWeight": 100
    }, {});
    FBox0cd48d585cadd45.setDefaultUnit(kony.flex.DP);
    var Button0gfe129f2b3a441 = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "Button0gfe129f2b3a441",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslButtonGlossBlue0g45ebbac2bb141",
        "text": "Button",
        "top": "0dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [6, 6, 6, 6],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    FBox0cd48d585cadd45.add(Button0gfe129f2b3a441);
}