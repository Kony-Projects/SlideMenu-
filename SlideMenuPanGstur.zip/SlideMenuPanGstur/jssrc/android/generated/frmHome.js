function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var LblPraveen = new kony.ui.Label({
        "id": "LblPraveen",
        "isVisible": true,
        "left": "140dp",
        "skin": "slLabel",
        "text": "Praveen",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "126dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var ButtonM = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "ButtonM",
        "isVisible": true,
        "left": "0dp",
        "onClick": AS_Button_ge0ad1cc07174573a60d7c2ed6c60636,
        "skin": "CopyslButtonGlossBlue0ce0a9a91310e4e",
        "text": "=",
        "top": "0dp",
        "width": "50dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var FlexContainerPan = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "FlexContainerPan",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-300dp",
        "skin": "CopyslFbox0h062e0dd51d54b",
        "width": "300dp",
        "zIndex": 1
    }, {}, {});
    FlexContainerPan.setDefaultUnit(kony.flex.DP);
    initializeFBox0cd48d585cadd45 && initializeFBox0cd48d585cadd45();
    var Segment0a5dec03206a143 = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "Button0gfe129f2b3a441": "Home"
        }, {
            "Button0gfe129f2b3a441": "Office"
        }, {
            "Button0gfe129f2b3a441": "About Us"
        }, {
            "Button0gfe129f2b3a441": "Menu"
        }, {
            "Button0gfe129f2b3a441": "Games"
        }, {
            "Button0gfe129f2b3a441": "Tv"
        }, {
            "Button0gfe129f2b3a441": "Add"
        }, {
            "Button0gfe129f2b3a441": "Remote"
        }, {
            "Button0gfe129f2b3a441": "Calculate"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "Segment0a5dec03206a143",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg0a9a57d49eb3141",
        "rowTemplate": FBox0cd48d585cadd45,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "Button0gfe129f2b3a441": "Button0gfe129f2b3a441"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainerPan.add(Segment0a5dec03206a143);
    frmHome.add(LblPraveen, ButtonM, FlexContainerPan);
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_c4303ed698814871af8a170a73397cf7,
        "skin": "sknFrmBG"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};